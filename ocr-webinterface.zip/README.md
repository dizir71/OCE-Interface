# OCR Webinterface Projekt

Installationsanleitung folgt.